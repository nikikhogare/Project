package com.app.pojo;

public enum Role {
	ADMIN,EMPLOYEE,CUSTOMER

}
