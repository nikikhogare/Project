package com.app.pojo;




public enum CourierType {
	


DOCUMENT,
ELECTRONICS,
METAL,
WOODEN
}
