package com.app.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;

public enum Status {
	BOOKED,SHIPPED_IN_TRANSIT ,ARRIVED_AT_DESTINATION,DELIVERED

}
